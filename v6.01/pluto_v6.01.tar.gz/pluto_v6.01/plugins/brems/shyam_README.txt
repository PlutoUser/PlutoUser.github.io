The files

* shyam_pp_1.25GeV.lst
* shyam_pn_1GeV.lst
* shyam_pn_1.25GeV.lst
* shyam_pn_1.5GeV.lst

have been supported by R. Shyam / priv. comm.

The colums have the following syntax:

   M(GeV)      TOTAL(mb)    BREMS(mb)    DELTA(mb)   N*(1520)(mb)

