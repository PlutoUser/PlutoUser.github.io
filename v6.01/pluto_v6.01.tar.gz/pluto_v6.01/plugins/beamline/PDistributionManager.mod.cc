//this line is added to the PDistributionManager.cc

PluginInfo("Beam line simulation classes available");

