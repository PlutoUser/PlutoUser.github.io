char *version_string = (char*) "6.00";
