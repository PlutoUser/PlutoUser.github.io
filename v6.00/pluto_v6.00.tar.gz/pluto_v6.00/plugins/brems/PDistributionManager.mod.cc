//this line is added to the PDistributionManager.cc

AddPlugin(new PBremsstrahlungPlugin("brems","Plugin for Bremsstrahlung models"));

