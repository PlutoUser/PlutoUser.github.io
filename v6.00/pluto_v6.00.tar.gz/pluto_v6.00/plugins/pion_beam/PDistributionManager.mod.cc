//this line is added to the PDistributionManager.cc

PluginInfo("Pion beam plugin available");
AddPlugin(new PPionBeamPlugin("pion_beam","Plugin for physics with pion beams"));

