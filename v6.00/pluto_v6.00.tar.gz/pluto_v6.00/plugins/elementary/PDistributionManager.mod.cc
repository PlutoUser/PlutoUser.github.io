//this line is added to the PDistributionManager.cc

AddPlugin(new PElementaryPlugin("elementary", "Plugin for elementary collisions/ total cross section"));
PluginInfo("Elementary plugin available");

