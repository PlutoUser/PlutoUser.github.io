//this line is added to the PDistributionManager.cc

PluginInfo("HADES classes available");

