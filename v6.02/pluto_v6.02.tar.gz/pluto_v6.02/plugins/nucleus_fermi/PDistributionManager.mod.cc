//this line is added to the PDistributionManager.cc

AddPlugin(new PNucleusFermiPlugin("nucleus_fermi","Fermi motion for some targets"));
